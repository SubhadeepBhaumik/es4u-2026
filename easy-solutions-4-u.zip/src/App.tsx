/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { HeroHeader } from './components/HeroHeader';
import { AgentVisualizer } from './components/AgentVisualizer';
import { MetricsStrip } from './components/MetricsStrip';
import { StudioCapabilities } from './components/StudioCapabilities';
import { ArchitectureSection } from './components/ArchitectureSection';
import { ScopeEstimatorSection } from './components/ScopeEstimatorSection';
import { CaseStudiesSection } from './components/CaseStudiesSection';
import { Footer } from './components/Footer';
import { ConsultationModal } from './components/ConsultationModal';
import { SandboxModal } from './components/SandboxModal';
import { WORKFLOW_TASKS } from './data/workflowPresets';
import { WorkflowTask } from './types';

export default function App() {
  const [consultationOpen, setConsultationOpen] = useState(false);
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [activeSandboxTask, setActiveSandboxTask] = useState<WorkflowTask>(WORKFLOW_TASKS[0]);

  const handleOpenSandboxWithTask = (task: WorkflowTask) => {
    setActiveSandboxTask(task);
    setSandboxOpen(true);
  };

  const handleNavigateSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen bg-slate-50 text-slate-900 selection:bg-blue-100 selection:text-blue-900 overflow-x-hidden font-sans">
      {/* Light Architectural Grid and Ambient Glows */}
      <div className="fixed inset-0 bg-grid-tech opacity-60 pointer-events-none z-0" />
      <div className="fixed top-0 left-1/4 w-[600px] h-[400px] bg-blue-100/50 rounded-full blur-[120px] pointer-events-none z-0" />
      <div className="fixed top-1/3 right-10 w-[500px] h-[350px] bg-sky-100/50 rounded-full blur-[100px] pointer-events-none z-0" />

      {/* Floating Navigation Bar */}
      <Navbar
        onOpenConsultation={() => setConsultationOpen(true)}
        onOpenSandbox={() => setSandboxOpen(true)}
        onNavigateSection={handleNavigateSection}
      />

      {/* Main Content Canvas */}
      <main className="relative z-10">
        {/* HERO SECTION - Master Split Command Center */}
        <section
          id="hero"
          className="relative pt-28 sm:pt-32 lg:pt-36 pb-12 sm:pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto w-full"
        >
          {/* Master Split Hero: High-Converting Copy + Interactive AI Neural Cockpit */}
          <HeroHeader
            onOpenConsultation={() => setConsultationOpen(true)}
            onOpenSandbox={() => setSandboxOpen(true)}
          />

          {/* Interactive Workflow & Distributed Agent Pipeline */}
          <div className="w-full mt-14 sm:mt-16">
            <AgentVisualizer onOpenSandboxModal={handleOpenSandboxWithTask} />
          </div>

          {/* Authority Metric Strip */}
          <MetricsStrip />
        </section>

        {/* Supporting Architectural Sections */}
        <div className="px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-24 sm:space-y-32 mb-24">
          <StudioCapabilities onOpenConsultation={() => setConsultationOpen(true)} />
          <ArchitectureSection />
          <ScopeEstimatorSection onOpenConsultation={() => setConsultationOpen(true)} />
          <CaseStudiesSection onOpenConsultation={() => setConsultationOpen(true)} />
        </div>
      </main>

      {/* Studio Footer */}
      <Footer
        onOpenConsultation={() => setConsultationOpen(true)}
        onOpenSandbox={() => setSandboxOpen(true)}
      />

      {/* Interactive Modals */}
      <ConsultationModal
        isOpen={consultationOpen}
        onClose={() => setConsultationOpen(false)}
      />

      <SandboxModal
        isOpen={sandboxOpen}
        onClose={() => setSandboxOpen(false)}
        task={activeSandboxTask}
      />
    </div>
  );
}
