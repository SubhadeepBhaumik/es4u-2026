import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Cpu, 
  Database, 
  Code2, 
  Wrench, 
  CheckCircle2, 
  Play, 
  Pause,
  RotateCcw, 
  Zap, 
  Layers, 
  ArrowRight, 
  Clock, 
  Sparkles,
  Workflow,
  Activity,
  Sliders,
  ShieldCheck
} from 'lucide-react';
import { WORKFLOW_TASKS } from '../data/workflowPresets';
import { WorkflowTask } from '../types';

interface AgentVisualizerProps {
  onOpenSandboxModal: (task: WorkflowTask) => void;
}

export const AgentVisualizer: React.FC<AgentVisualizerProps> = ({ onOpenSandboxModal }) => {
  const [activeTaskIndex, setActiveTaskIndex] = useState(0);
  const [activeStage, setActiveStage] = useState<'idle' | 'input' | 'router' | 'workers' | 'output'>('workers');
  const [isPlaying, setIsPlaying] = useState(true);
  const [selectedNodeId, setSelectedNodeId] = useState<string>('router');
  const [cycleTick, setCycleTick] = useState(0);

  const currentTask = WORKFLOW_TASKS[activeTaskIndex];

  // Simulation step loop when playing
  useEffect(() => {
    if (!isPlaying) return;

    const stages: ('input' | 'router' | 'workers' | 'output')[] = ['input', 'router', 'workers', 'output'];
    let currentStageIndex = 0;

    const interval = setInterval(() => {
      currentStageIndex = (currentStageIndex + 1) % stages.length;
      setActiveStage(stages[currentStageIndex]);
      if (currentStageIndex === 0) {
        setCycleTick((prev) => prev + 1);
      }
    }, 2400);

    return () => clearInterval(interval);
  }, [isPlaying, activeTaskIndex]);

  const handleTaskChange = (index: number) => {
    setActiveTaskIndex(index);
    setActiveStage('input');
    setCycleTick((prev) => prev + 1);
  };

  const handleReset = () => {
    setActiveStage('input');
    setCycleTick((prev) => prev + 1);
  };

  return (
    <div
      id="agent-visualizer-container"
      className="relative w-full rounded-3xl bg-white border border-slate-200 shadow-xl shadow-slate-900/5 group overflow-hidden"
    >
      <div className="relative w-full h-full p-5 sm:p-7 overflow-hidden">
        
        {/* Soft Ambient Background Highlights */}
        <div className="absolute top-0 right-10 w-96 h-96 bg-blue-50/70 rounded-full blur-[100px] pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-sky-50/70 rounded-full blur-[90px] pointer-events-none" />

        {/* Visualizer Top Control Bar */}
        <div
          id="visualizer-header-controls"
          className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-5 border-b border-slate-200 relative z-10"
        >
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-blue-50 border border-blue-200 text-xs font-semibold text-blue-900 shadow-xs">
              <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
              <span className="font-bold tracking-tight">Interactive Workflow Pipeline</span>
              <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-600 text-white">LIVE</span>
            </div>

            <div className="flex items-center gap-2.5 text-xs text-slate-600">
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 border border-slate-200">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                <span>Execution Time: <strong className="text-slate-900">{currentTask.totalLatency}</strong></span>
              </div>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Accuracy: <strong className="text-emerald-900">{currentTask.confidenceScore}</strong></span>
              </div>
            </div>
          </div>

          {/* Workflow scenario tabs & Playback controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            <div className="flex items-center p-1 rounded-xl bg-slate-100 border border-slate-200 overflow-x-auto max-w-full">
              {WORKFLOW_TASKS.map((task, idx) => (
                <button
                  key={task.id}
                  id={`task-selector-${task.id}`}
                  type="button"
                  onClick={() => handleTaskChange(idx)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all whitespace-nowrap flex items-center gap-1.5 ${
                    activeTaskIndex === idx
                      ? 'bg-blue-600 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                  }`}
                >
                  <Workflow className="w-3 h-3" />
                  <span>{task.label}</span>
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1.5">
              <button
                id="visualizer-play-toggle"
                type="button"
                onClick={() => setIsPlaying(!isPlaying)}
                className={`p-2 rounded-xl border transition-all ${
                  isPlaying 
                    ? 'bg-blue-50 border-blue-200 text-blue-700 shadow-xs' 
                    : 'bg-slate-100 hover:bg-slate-200 border-slate-200 text-slate-700'
                }`}
                title={isPlaying ? 'Pause Simulation' : 'Run Simulation'}
                aria-label={isPlaying ? 'Pause Simulation' : 'Run Simulation'}
              >
                {isPlaying ? <Pause className="w-4 h-4 text-blue-700" /> : <Play className="w-4 h-4 text-slate-700" />}
              </button>
              <button
                id="visualizer-reset-button"
                type="button"
                onClick={handleReset}
                className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 transition-colors"
                title="Re-run Pipeline"
                aria-label="Re-run Pipeline"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Main Workflow Canvas & Nodes Grid */}
        <div id="visualizer-canvas-grid" className="relative py-6 lg:py-8">
          
          {/* Desktop Architecture Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-center relative z-10">
            
            {/* Node 1: User Task Input (Cols 1-3) */}
            <div className="lg:col-span-3 flex flex-col gap-3">
              <div
                id="node-user-task-input"
                onClick={() => setSelectedNodeId('input')}
                className={`relative cursor-pointer p-4 rounded-2xl border transition-all duration-300 bg-white hover:-translate-y-1 ${
                  selectedNodeId === 'input'
                    ? 'border-sky-500 shadow-xl shadow-sky-500/15 scale-[1.02] ring-2 ring-sky-200'
                    : 'border-slate-200 hover:border-sky-400 hover:shadow-lg hover:shadow-sky-500/10'
                } ${activeStage === 'input' ? 'ring-2 ring-sky-400' : ''}`}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-sky-500 text-white flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform">
                      <Terminal className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold text-slate-900 tracking-tight">
                      Task Ingestion
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-50 border border-sky-200 text-sky-700 font-bold">
                    Input
                  </span>
                </div>

                {/* Body */}
                <p className="text-xs text-slate-700 line-clamp-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {currentTask.inputPrompt}
                </p>

                {/* Status footer */}
                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="text-sky-700 font-medium flex items-center gap-1">
                    <Activity className="w-3 h-3 text-sky-600" /> Real-time stream
                  </span>
                  <span className="font-semibold text-slate-700">Validated</span>
                </div>
              </div>

              {/* Connecting Indicator for Mobile */}
              <div className="flex lg:hidden justify-center text-sky-500 py-1">
                <ArrowRight className="w-4 h-4 rotate-90 animate-bounce" />
              </div>
            </div>

            {/* Node 2: Router Agent (Decision Engine) (Cols 4-6) */}
            <div className="lg:col-span-3 flex flex-col gap-3">
              <div
                id="node-router-agent"
                onClick={() => setSelectedNodeId('router')}
                className={`relative cursor-pointer p-4 rounded-2xl border transition-all duration-300 bg-white hover:-translate-y-1 ${
                  selectedNodeId === 'router'
                    ? 'border-blue-600 shadow-xl shadow-blue-600/15 scale-[1.02] ring-2 ring-blue-200'
                    : 'border-slate-200 hover:border-blue-400 hover:shadow-lg hover:shadow-blue-500/10'
                } ${activeStage === 'router' ? 'ring-2 ring-blue-500' : ''}`}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-blue-600 text-white flex items-center justify-center shadow-xs">
                      <Cpu className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold text-slate-900 tracking-tight">
                      Decision Router
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-50 border border-blue-200 text-blue-700 font-bold">
                    Fast Path
                  </span>
                </div>

                {/* Body */}
                <div className="text-xs text-slate-700 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  <div className="text-[10px] text-blue-800 mb-1 flex items-center gap-1 font-bold">
                    <Sliders className="w-3 h-3 text-blue-600" />
                    System Routing Logic:
                  </div>
                  <p className="line-clamp-3 text-[11px] text-slate-600 leading-snug">
                    {currentTask.routerDecision}
                  </p>
                </div>

                {/* Status footer */}
                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="flex items-center gap-1 text-blue-700 font-semibold">
                    <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse" />
                    Multi-worker parallel
                  </span>
                  <span className="text-slate-600 font-medium">Auto-balanced</span>
                </div>
              </div>

              {/* Connecting Indicator for Mobile */}
              <div className="flex lg:hidden justify-center text-blue-600 py-1">
                <ArrowRight className="w-4 h-4 rotate-90 animate-bounce" />
              </div>
            </div>

            {/* Node 3: Split to 3 Worker Agents (Cols 7-9) */}
            <div className="lg:col-span-3 flex flex-col gap-2.5">
              {/* Worker 1: RAG & Vector Retrieval */}
              <div
                id="node-worker-rag"
                onClick={() => setSelectedNodeId('worker-rag')}
                className={`p-3 rounded-2xl border transition-all duration-250 cursor-pointer bg-white hover:-translate-y-0.5 ${
                  selectedNodeId === 'worker-rag'
                    ? 'border-sky-500 bg-sky-50/60 shadow-md ring-2 ring-sky-200'
                    : 'border-slate-200 hover:border-sky-300 hover:bg-sky-50/25 hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-sky-100 text-sky-700">
                      <Database className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-slate-900">Knowledge Retrieval</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-100 text-sky-800 font-semibold">
                    RAG
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 line-clamp-1">
                  Vector index query &bull; Enterprise policy lookup
                </p>
              </div>

              {/* Worker 2: Code Execution Engine */}
              <div
                id="node-worker-code"
                onClick={() => setSelectedNodeId('worker-code')}
                className={`p-3 rounded-2xl border transition-all duration-250 cursor-pointer bg-white hover:-translate-y-0.5 ${
                  selectedNodeId === 'worker-code'
                    ? 'border-indigo-500 bg-indigo-50/60 shadow-md ring-2 ring-indigo-200'
                    : 'border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/25 hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-indigo-100 text-indigo-700">
                      <Code2 className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-slate-900">Business Logic Engine</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold">
                    Core Compute
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 line-clamp-1">
                  Sandboxed calculation &bull; Formula execution
                </p>
              </div>

              {/* Worker 3: External Tool / API Call */}
              <div
                id="node-worker-tool"
                onClick={() => setSelectedNodeId('worker-tool')}
                className={`p-3 rounded-2xl border transition-all duration-250 cursor-pointer bg-white hover:-translate-y-0.5 ${
                  selectedNodeId === 'worker-tool'
                    ? 'border-emerald-500 bg-emerald-50/60 shadow-md ring-2 ring-emerald-200'
                    : 'border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/25 hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-700">
                      <Wrench className="w-3.5 h-3.5" />
                    </div>
                    <span className="text-xs font-bold text-slate-900">Enterprise Integrations</span>
                  </div>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-100 text-emerald-800 font-semibold">
                    API / ERP
                  </span>
                </div>
                <p className="text-[11px] text-slate-600 line-clamp-1">
                  Secure connectors &bull; Zero data leak guarantee
                </p>
              </div>

              {/* Connecting Indicator for Mobile */}
              <div className="flex lg:hidden justify-center text-emerald-600 py-1">
                <ArrowRight className="w-4 h-4 rotate-90 animate-bounce" />
              </div>
            </div>

            {/* Node 4: Consolidated Verified Output (Cols 10-12) */}
            <div className="lg:col-span-3 flex flex-col gap-3">
              <div
                id="node-consolidated-output"
                onClick={() => setSelectedNodeId('output')}
                className={`relative cursor-pointer p-4 rounded-2xl border transition-all duration-300 bg-white hover:-translate-y-1 ${
                  selectedNodeId === 'output'
                    ? 'border-emerald-600 shadow-xl shadow-emerald-600/15 scale-[1.02] ring-2 ring-emerald-200'
                    : 'border-slate-200 hover:border-emerald-400 hover:shadow-lg hover:shadow-emerald-500/10'
                } ${activeStage === 'output' ? 'ring-2 ring-emerald-500' : ''}`}
              >
                {/* Header */}
                <div className="flex items-center justify-between mb-2.5">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-bold text-slate-900 tracking-tight">
                      Validated Synthesis
                    </span>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-700 font-bold">
                    DELIVERED
                  </span>
                </div>

                {/* Body */}
                <p className="text-xs text-slate-700 line-clamp-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                  {currentTask.finalOutput}
                </p>

                {/* Status footer */}
                <div className="mt-2.5 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                  <span className="text-emerald-700 font-semibold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" /> Verified safe
                  </span>
                  <span className="text-slate-700 font-bold">{currentTask.totalLatency}</span>
                </div>
              </div>
            </div>

          </div>

          {/* Connection Lines behind nodes on Desktop */}
          <div className="hidden lg:block absolute inset-0 pointer-events-none z-0">
            <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
              <line x1="24%" y1="50%" x2="26%" y2="50%" stroke="#93c5fd" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="49%" y1="50%" x2="51%" y2="28%" stroke="#93c5fd" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="49%" y1="50%" x2="51%" y2="50%" stroke="#93c5fd" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="49%" y1="50%" x2="51%" y2="72%" stroke="#93c5fd" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="74%" y1="28%" x2="76%" y2="50%" stroke="#86efac" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="74%" y1="50%" x2="76%" y2="50%" stroke="#86efac" strokeWidth="2" strokeDasharray="4 4" />
              <line x1="74%" y1="72%" x2="76%" y2="50%" stroke="#86efac" strokeWidth="2" strokeDasharray="4 4" />
            </svg>
          </div>
        </div>

        {/* Interactive Telemetry Inspector Strip */}
        <div
          id="visualizer-inspector-drawer"
          className="mt-4 pt-4 border-t border-slate-200 bg-slate-50 rounded-2xl p-4 text-xs text-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-3 border border-slate-200"
        >
          <div className="flex items-center gap-2.5 overflow-hidden">
            <span className="px-2.5 py-1 rounded-lg bg-blue-100 text-blue-900 font-bold uppercase text-[11px] shrink-0">
              Inspector: {selectedNodeId.toUpperCase()}
            </span>
            <span className="text-slate-400 hidden sm:inline">&bull;</span>
            <span className="text-slate-700 truncate text-[12px]">
              {selectedNodeId === 'input' && `Input Stream: "${currentTask.inputPrompt}"`}
              {selectedNodeId === 'router' && `Router Logic: ${currentTask.routerDecision}`}
              {selectedNodeId === 'worker-rag' && `Knowledge Retrieval: ${currentTask.workerOutputs.rag}`}
              {selectedNodeId === 'worker-code' && `Compute Engine: ${currentTask.workerOutputs.code}`}
              {selectedNodeId === 'worker-tool' && `Integration Call: ${currentTask.workerOutputs.tool}`}
              {selectedNodeId === 'output' && `Output Delivered: ${currentTask.finalOutput}`}
            </span>
          </div>

          <button
            id="visualizer-open-sandbox-btn"
            type="button"
            onClick={() => onOpenSandboxModal(currentTask)}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs transition-all shadow-sm whitespace-nowrap self-end md:self-auto group active:scale-95"
          >
            <span>Launch Live Sandbox</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

      </div>
    </div>
  );
};

