import React, { useState, useEffect } from 'react';
import { ArrowUpRight, Menu, X, Sparkles, Layers, PhoneCall } from 'lucide-react';
import { EasySolutionsLogo } from './EasySolutionsLogo';

interface NavbarProps {
  onOpenConsultation: () => void;
  onOpenSandbox: () => void;
  onNavigateSection?: (sectionId: string) => void;
  activeSection?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenConsultation,
  onOpenSandbox,
  onNavigateSection,
  activeSection = 'hero',
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (e: React.MouseEvent, id: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    if (id === 'sandbox') {
      onOpenSandbox();
      return;
    }
    if (onNavigateSection) {
      onNavigateSection(id);
    }
  };

  return (
    <header
      id="main-navigation"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 px-3 sm:px-6 lg:px-8 ${
        isScrolled ? 'pt-2.5 pb-2' : 'pt-4 sm:pt-5 pb-3'
      }`}
    >
      <div className="max-w-7xl mx-auto">
        <nav
          id="navbar-container"
          className="relative flex items-center justify-between px-4 sm:px-6 py-3 rounded-2xl bg-white/95 backdrop-blur-md border border-slate-200 shadow-md shadow-slate-900/5"
        >
          {/* Brand Logo with exact user identity */}
          <a
            id="nav-brand-link"
            href="#hero"
            onClick={(e) => handleLinkClick(e, 'hero')}
            className="flex items-center gap-3 text-left focus:outline-none"
            aria-label="Easy Solutions 4 U Home"
          >
            <EasySolutionsLogo size="md" variant="horizontal" />
            <span className="hidden lg:inline-block pl-3 border-l border-slate-200 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
              Enterprise Solutions Architecture
            </span>
          </a>

          {/* Desktop Navigation Links */}
          <div
            id="nav-desktop-links"
            className="hidden md:flex items-center gap-1.5 text-xs font-semibold text-slate-600"
          >
            <button
              id="nav-link-overview"
              type="button"
              onClick={(e) => handleLinkClick(e, 'hero')}
              className="px-3 py-1.5 rounded-lg hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
            >
              Overview
            </button>
            <button
              id="nav-link-capabilities"
              type="button"
              onClick={(e) => handleLinkClick(e, 'capabilities')}
              className="px-3 py-1.5 rounded-lg hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
            >
              Solutions &amp; Capabilities
            </button>
            <button
              id="nav-link-architecture"
              type="button"
              onClick={(e) => handleLinkClick(e, 'architecture')}
              className="px-3 py-1.5 rounded-lg hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
            >
              Architecture
            </button>
            <button
              id="nav-link-casestudies"
              type="button"
              onClick={(e) => handleLinkClick(e, 'case-studies')}
              className="px-3 py-1.5 rounded-lg hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
            >
              Case Studies
            </button>
            <button
              id="nav-link-estimator"
              type="button"
              onClick={(e) => handleLinkClick(e, 'scope-estimator')}
              className="px-3 py-1.5 rounded-lg hover:text-blue-700 hover:bg-blue-50 transition-colors cursor-pointer"
            >
              Scope Estimator
            </button>
            <button
              id="nav-link-sandbox"
              type="button"
              onClick={(e) => handleLinkClick(e, 'sandbox')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-blue-700 bg-blue-50/80 hover:bg-blue-100 hover:text-blue-800 transition-all duration-200 border border-blue-200/80 hover:border-blue-300 hover:scale-105 shadow-2xs cursor-pointer"
            >
              <Layers className="w-3.5 h-3.5 text-blue-600" />
              <span>Interactive Sandbox</span>
            </button>
          </div>

          {/* Right Action CTA */}
          <div className="flex items-center gap-2">
            <button
              id="nav-cta-consultation"
              type="button"
              onClick={onOpenConsultation}
              className="relative inline-flex items-center justify-center gap-2 px-5 py-2.5 text-xs font-bold text-white rounded-xl bg-blue-600 hover:bg-blue-700 active:scale-95 transition-all duration-250 shadow-md shadow-blue-600/20 hover:shadow-lg hover:shadow-blue-600/35 hover:-translate-y-0.5 cursor-pointer group"
            >
              <PhoneCall className="w-3.5 h-3.5 text-blue-200 group-hover:scale-110 transition-transform" />
              <span>Talk to an Architect</span>
              <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>

            {/* Mobile Menu Toggle Button */}
            <button
              id="nav-mobile-menu-toggle"
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 transition-colors cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </nav>

        {/* Mobile Dropdown Panel */}
        {mobileMenuOpen && (
          <div
            id="nav-mobile-menu-panel"
            className="md:hidden mt-2 p-4 rounded-2xl border border-slate-200 bg-white/98 backdrop-blur-xl shadow-xl space-y-2 text-slate-700 text-sm font-semibold"
          >
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'hero')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl hover:bg-slate-100 text-left cursor-pointer"
            >
              <span>Overview</span>
            </button>
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'capabilities')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl hover:bg-slate-100 text-left cursor-pointer"
            >
              <span>Solutions &amp; Capabilities</span>
            </button>
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'architecture')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl hover:bg-slate-100 text-left cursor-pointer"
            >
              <span>Architecture Blueprints</span>
            </button>
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'case-studies')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl hover:bg-slate-100 text-left cursor-pointer"
            >
              <span>Case Studies &amp; ROI</span>
            </button>
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'scope-estimator')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl hover:bg-slate-100 text-left cursor-pointer"
            >
              <span>Scope Estimator</span>
            </button>
            <button
              type="button"
              onClick={(e) => handleLinkClick(e, 'sandbox')}
              className="w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-blue-50 text-blue-700 text-left cursor-pointer"
            >
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-blue-600" />
                <span>Interactive Sandbox</span>
              </div>
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
